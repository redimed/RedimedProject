/** Automatically generated file. DO NOT MODIFY */
package com.ionicframework.injurymanagement949685;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}