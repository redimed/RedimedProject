package org.apache.cordova.api;

// dummy class to ensure the org.apache.cordova.api package exists
// this is required to support Cordova 2.9 and 3.0 with one code base
// since I'm using wildcard imports to work around the renamed classes
// import org.apache.cordova.*;
// import org.apache.cordova.api.*;
public class Dummy {
}