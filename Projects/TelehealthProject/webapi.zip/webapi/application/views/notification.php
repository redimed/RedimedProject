<div data-role="dialog" id="alert">
    <div data-role="content" data-theme="c">
        <h1>Success!</h1>
        <p>Your information has been submitted. Click OK to go back.</p>
        <a href="<?= $url;?>" data-role="button" data-inline="true" data-icon="check" data-theme="c" data-ajax="false">OK</a>  
    </div>
</div>