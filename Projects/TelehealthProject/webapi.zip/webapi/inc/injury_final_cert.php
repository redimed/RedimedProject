<?php

$pdf->SetFontSize(10, true);
$this->load->model('progress_model');
$progress = $this->progress_model->get($this->uri->segment(5)); 
if (count($progress)>0){
	$json = $progress[0]['detail'];
	preg_match('#^data:[\w/]+(;[\w=]+)*,[\w+/=%]+$#', $json);
	
	//echo urldecode($json).'<br>';
	$progress[0]['detail'] = json_decode($json,true);
	//print_r($progress)
	$pdata = $progress[0]['detail'];
}else
	$pdata = array();

//print_r($pdata);
// get the current page break margin
$bMargin = $pdf->getBreakMargin();
// get current auto-page-break mode
$auto_page_break = $pdf->getAutoPageBreak();
// disable auto-page-break
$pdf->SetAutoPageBreak(false, 0);
// set bacground image
$img_file = "images/Two_Hands_Final.png";
$checkMark = "images/CheckMark.jpg";
$pdf->Image($img_file, 0, 0, 210, 297, '', '', '', false, 300, '', false, false, 0);
// restore auto-page-break status
//$pdf->SetAutoPageBreak($auto_page_break, $bMargin);
// set the starting point for the page content
$pdf->setPageMark();
$pdf->setPage(1);

// start printing data
$pdf->writeHTMLCell($w=40, $h=0, $x=46, $y=84, $salutation[$data['data']['salut']-1].' '.$data['data']['gname'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); //first name
$pdf->writeHTMLCell($w=40, $h=0, $x=125, $y=84, $data['data']['fname'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // last name
$pdf->writeHTMLCell($w=140, $h=0, $x=38, $y=89, $data['data']['address'].(($data['data']['suburb']!='')?', ':'').$data['data']['suburb'].(($data['data']['postcode']!='')?', ':'').$data['data']['postcode'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // address
$pdf->writeHTMLCell($w=80, $h=0, $x=42, $y=94, $data['data']['wfone'].(($data['data']['hfone']!='')?'-':'').$data['data']['hfone'].(($data['data']['mfone']!='')?'-':'').$data['data']['mfone'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // fone
$pdf->writeHTMLCell($w=40, $h=0, $x=97, $y=99, $data['data']['adate'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // date
$pdf->writeHTMLCell($w=40, $h=0, $x=97, $y=103.5, $data['data']['alocation'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // location
						
$pdf->writeHTMLCell($w=140, $h=8, $x=22, $y=43, $data['employer']['name'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
$pdf->writeHTMLCell($w=140, $h=8, $x=22, $y=48, $data['employer']['address'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);// employer's detail

if (array_key_exists('f-assessment-1',$pdata)) 
	if ('on'==$pdata['f-assessment-1'])
		$pdf->Image($checkMark,19, 126.5, 3.5, 3.5, '', '', '', false, 300, '', false, false, 0); //Fit to return to pre-injury duties
if (array_key_exists('f-assessment-2',$pdata))
	if ('on'==$pdata['f-assessment-2'])
		$pdf->Image($checkMark,19, 131, 3.5, 3.5, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('f-assessment-3',$pdata))
	if ('on'==$pdata['f-assessment-3'])
		$pdf->Image($checkMark,19, 136.5, 3.5, 3.5, '', '', '', false, 300, '', false, false, 0);
		
$pdf->writeHTMLCell($w=40, $h=0, $x=120, $y=121.5, ((array_key_exists('f-from-date1',$pdata))?$pdata['f-from-date1']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 

if (array_key_exists('f-assessment-4',$pdata))
	if ('on'==$pdata['f-assessment-4'])
		$pdf->Image($checkMark, 19, 151, 3.5, 3.5, '', '', '', false, 300, '', false, false, 0); //restricted hours
$pdf->writeHTMLCell($w=170, $h=0, $x=77, $y=145, ((array_key_exists('f-from-date',$pdata))?$pdata['f-from-date']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
if (array_key_exists('f-assessment-5',$pdata))
	if ('on'==$pdata['f-assessment-5']){
		$pdf->Image($checkMark, 19, 155.5, 3.5, 3.5, '', '', '', false, 300, '', false, false, 0);
		$pdf->writeHTMLCell($w=170, $h=0, $x=24, $y=162, ((array_key_exists('f-fittxt',$pdata))?$pdata['f-fittxt']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
}
if (array_key_exists('f-assessment-6',$pdata))
	if ('on'==$pdata['f-assessment-6'])
		$pdf->Image($checkMark, 24.5, 206, 3.5, 3.5, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('f-assessment-7',$pdata))
	if ('on'==$pdata['f-assessment-7'])
		$pdf->Image($checkMark,24.5, 213, 3.5, 3.5, '', '', '', false, 300, '', false, false, 0); //Work restrictions		 

if (''!=$data['data']['drsign']){
	//$imgdata = base64_decode(substr($data['data']['drsigntxt'],22));
	//$imgdata = str_replace(' ','+',$imgdata);
	
	$imgdata = $drsign;
	$imgdata = str_replace(' ','+',$imgdata);
	
	preg_match('#^data:[\w/]+(;[\w=]+)*,[\w+/=%]+$#', $imgdata);
	
	//echo $imgdata;
	copy("data:image/png;base64,".$imgdata,"output/temp.png");
	
	//file_put_contents("output/temp.png", $imgdata);
	//fclose($image);
	list($width, $height, $type, $attr)= getimagesize("output/temp.png"); 
	//echo substr($pdata['drsigntxt'],22);
	$pdf->Image("output/temp.png", 45, 257, 20, 20*$height/$width, '', '', '', false, 300, '', false, false, 0);
	//$pdf->Image("output/temp.png", 10, 10, 50, 20, '', '', '', false, 300, '', false, false, 0);
	//$pdf->Image('@'.$imgdata);
}

$pdf->writeHTMLCell($w=40, $h=0, $x=88, $y=69, ((array_key_exists('examdate',$pdata))?$pdata['examdate']:"").'  '.((array_key_exists('examtime',$pdata))?$pdata['examtime']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 

// redimed's detail
$pdf->writeHTMLCell($w=70, $h=0, $x=40, $y=236.5, ((array_key_exists('dname',$pdata))?$pdata['dname']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
$pdf->writeHTMLCell($w=70, $h=0, $x=147, $y=236.5, ((array_key_exists('dcode',$pdata))?$pdata['dcode']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
$pdf->writeHTMLCell($w=70, $h=0, $x=40, $y=241.5, ((array_key_exists('daddress',$pdata))?$pdata['daddress']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=70, $h=0, $x=40, $y=246.5, "(08) 9230 0900", $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);

$pdf->writeHTMLCell($w=70, $h=0, $x=27, $y=251.5, "(08)9230 0999", $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);

?>