<?php

// get progress data
//$pdf->AddPage();
$this->load->model('progress_model');
$progress = $this->progress_model->get($this->uri->segment(5)); 
if (count($progress)>0){
	$json = $progress[0]['detail'];
	preg_match('#^data:[\w/]+(;[\w=]+)*,[\w+/=%]+$#', $json);
	
	//echo urldecode($json).'<br>';
	$progress[0]['detail'] = json_decode($json,true);
	//print_r($progress)
	$pdata = $progress[0]['detail'];
}else
	$pdata = array();

//print_r($progress);
// get the current page break margin
//$pdf->setPageMark();
$bMargin = $pdf->getBreakMargin();
// get current auto-page-break mode
$auto_page_break = $pdf->getAutoPageBreak();
// disable auto-page-break
$pdf->SetAutoPageBreak(false, 0);
// set bacground image
$img_file = "images/Two_Hands_Progress.png";
$checkMark = "images/CheckMark.jpg";
$pdf->Image($img_file, 0, 0, 210, 297, '', '', '', false, 300, '', false, false, 0);
// restore auto-page-break status
//$pdf->SetAutoPageBreak($auto_page_break, $bMargin);
// set the starting point for the page content
$pdf->setPageMark();
$pdf->setPage(1);
// start printing data
$pdf->writeHTMLCell($w=40, $h=0, $x=32, $y=41, $salutation[$data['data']['salut']-1].' '.$data['data']['gname'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); //first name
$pdf->writeHTMLCell($w=40, $h=0, $x=87, $y=41, $data['data']['fname'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // last name
$pdf->writeHTMLCell($w=140, $h=0, $x=31, $y=44.5, $data['data']['address'].(($data['data']['suburb']!='')?', ':'').$data['data']['suburb'].(($data['data']['postcode']!='')?', ':'').$data['data']['postcode'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // address
$pdf->writeHTMLCell($w=80, $h=0, $x=30, $y=48, $data['data']['wfone'].(($data['data']['hfone']!='')?'-':'').$data['data']['hfone'].(($data['data']['mfone']!='')?'-':'').$data['data']['mfone'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // fone
$pdf->writeHTMLCell($w=80, $h=0, $x=45, $y=52, $data['data']['adate'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // fone
$pdf->writeHTMLCell($w=40, $h=0, $x=88, $y=48, $data['data']['dob'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // dob
$pdf->writeHTMLCell($w=40, $h=0, $x=135, $y=48, ((array_key_exists('occupation',$data['data']))?$data['data']['occupation']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // occupation

$pdf->writeHTMLCell($w=140, $h=8, $x=57, $y=64, $data['employer']['name'].' - '.$data['employer']['address'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // employer's detail

$pdf->writeHTMLCell($w=185, $h=8, $x=16, $y=75, $pdata['p-massessment'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); //progress report

if (array_key_exists('p-assessment-1',$pdata)) 
	if ('on'==$pdata['p-assessment-1'])
		$pdf->Image($checkMark,14.5, 105, 3, 3, '', '', '', false, 300, '', false, false, 0); //Fit to return to pre-injury duties
if (array_key_exists('p-assessment-2',$pdata))
	if ('on'==$pdata['p-assessment-2'])
		$pdf->Image($checkMark,14.5, 108.5, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('p-assessment-3',$pdata))
	if ('on'==$pdata['p-assessment-3'])
		$pdf->Image($checkMark,14.5, 112, 3, 3, '', '', '', false, 300, '', false, false, 0);
$pdf->writeHTMLCell($w=40, $h=0, $x=60, $y=112, ((array_key_exists('p-dateFrom',$pdata))?$pdata['p-dateFrom']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=40, $h=0, $x=90, $y=112, ((array_key_exists('p-dateTo',$pdata))?$pdata['p-dateTo']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 

if (array_key_exists('p-assessment-4',$pdata))
	if ('on'==$pdata['p-assessment-4'])
		$pdf->Image($checkMark, 19, 115.5, 3, 3, '', '', '', false, 300, '', false, false, 0); //restricted hours
		$pdf->writeHTMLCell($w=40, $h=0, $x=60, $y=115.5, ((array_key_exists('p-restrictedHours',$pdata))?$pdata['p-restrictedHours']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
if (array_key_exists('p-assessment-5',$pdata))
	if ('on'==$pdata['p-assessment-5'])
		$pdf->Image($checkMark, 19, 119.5, 3, 3, '', '', '', false, 300, '', false, false, 0);
		$pdf->writeHTMLCell($w=40, $h=0, $x=60, $y=119.5, ((array_key_exists('p-restrictedDays',$pdata))?$pdata['p-restrictedDays']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
if (array_key_exists('p-assessment-6',$pdata))
	if ('on'==$pdata['p-assessment-6'])
		$pdf->Image($checkMark, 19, 123, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('p-assessment-7',$pdata))
	if ('on'==$pdata['p-assessment-7'])
		$pdf->Image($checkMark,14.5, 126.5, 3, 3, '', '', '', false, 300, '', false, false, 0); //Work restrictions
if (array_key_exists('p-assessment-8',$pdata))
	if ('on'==$pdata['p-assessment-8'])
		$pdf->Image($checkMark,14.5, 130.5, 3, 3, '', '', '', false, 300, '', false, false, 0); //
		$pdf->writeHTMLCell($w=40, $h=0, $x=53, $y=130.5, ((array_key_exists('p-weight',$pdata))?$pdata['p-weight']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
		$pdf->writeHTMLCell($w=60, $h=0, $x=105, $y=130.5, ((array_key_exists('p-otherRes',$pdata))?$pdata['p-otherRes']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
	
if (array_key_exists('p-assessment-9',$pdata))
	if ('on'==$pdata['p-assessment-9'])
		$pdf->Image($checkMark, 19, 134, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('p-assessment-10',$pdata))
	if ('on'==$pdata['p-assessment-10'])
		$pdf->Image($checkMark, 19, 137.5, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('p-assessment-11',$pdata))
	if ('on'==$pdata['p-assessment-11'])
		$pdf->Image($checkMark, 19, 141, 3, 3, '', '', '', false, 300, '', false, false, 0);// Avoid repetitive use
if (array_key_exists('p-assessment-12',$pdata))
	if ('on'==$pdata['p-assessment-12'])
		$pdf->Image($checkMark, 19, 145, 3, 3, '', '', '', false, 300, '', false, false, 0);  
if (array_key_exists('p-assessment-22',$pdata))
	if ('on'==$pdata['p-assessment-22'])
		$pdf->Image($checkMark, 19, 148.5, 3, 3, '', '', '', false, 300, '', false, false, 0);  // First and final certificate
if (array_key_exists('p-assessment-13',$pdata))
	if ('on'==$pdata['p-assessment-13'])
		$pdf->Image($checkMark, 19, 152, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
		$pdf->writeHTMLCell($w=40, $h=0, $x=57, $y=152.5, ((array_key_exists('p-unfitDays',$pdata))?$pdata['p-unfitDays']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
		$pdf->writeHTMLCell($w=60, $h=0, $x=73, $y=152.5, ((array_key_exists('p-unfitFrom',$pdata))?$pdata['p-unfitFrom']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
		$pdf->writeHTMLCell($w=40, $h=0, $x=100, $y=152.5, ((array_key_exists('p-unfitTo',$pdata))?$pdata['p-unfitTo']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
	
if (array_key_exists('p-assessment-14',$pdata))
	if ('on'==$pdata['p-assessment-14'])
		$pdf->Image($checkMark,14.5, 159.5, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
if (array_key_exists('p-assessment-15',$pdata))
	if ('on'==$pdata['p-assessment-15'])
		$pdf->Image($checkMark,14.5, 163, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
		
if (array_key_exists('p-assessment-16',$pdata))
	if ('on'==$pdata['p-assessment-16'])
		$pdf->Image($checkMark, 111.5, 163, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
		
if (array_key_exists('p-assessment-17',$pdata))
	if ('on'==$pdata['p-assessment-17'])
		$pdf->Image($checkMark,14.5, 166.5, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
		
		$pdf->writeHTMLCell($w=40, $h=0, $x=33, $y=159.5, ((array_key_exists('p-medicationtxt',$pdata))?$pdata['p-medicationtxt']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
		$pdf->writeHTMLCell($w=60, $h=0, $x=83, $y=163, ((array_key_exists('p-treatmenttxt',$pdata))?$pdata['p-treatmenttxt']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
		$pdf->writeHTMLCell($w=40, $h=0, $x=128, $y=163, ((array_key_exists('p-imagingtxt',$pdata))?$pdata['p-imagingtxt']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
		$pdf->writeHTMLCell($w=40, $h=0, $x=63, $y=166.5, ((array_key_exists('p-refertxt',$pdata))?$pdata['p-refertxt']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
		$pdf->writeHTMLCell($w=140, $h=0, $x=33, $y=174, ((array_key_exists('p-treatmentother',$pdata))?$pdata['p-treatmentother']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 

if (array_key_exists('p-assessment-18',$pdata))
	if ('on'==$pdata['p-assessment-18'])
		$pdf->Image($checkMark,14.5, 200, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
		
if (array_key_exists('p-assessment-19',$pdata))
	if ('on'==$pdata['p-assessment-19'])
		$pdf->Image($checkMark,14.5, 203.5, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
		
if (array_key_exists('p-assessment-20',$pdata))
	if ('on'==$pdata['p-assessment-20'])
		$pdf->Image($checkMark,14.5, 211, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
		
if (array_key_exists('p-assessment-23',$pdata))
	if ('on'==$pdata['p-assessment-23'])
		$pdf->Image($checkMark,14.5, 214.5, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
		
$pdf->writeHTMLCell($w=40, $h=0, $x=51, $y=190.5, ((array_key_exists('p-datenext',$pdata))?$pdata['p-datenext']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=40, $h=0, $x=94, $y=190.5, ((array_key_exists('p-timenext',$pdata))?$pdata['p-timenext']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 

if (array_key_exists('p-assessment-24',$pdata))
	if ('on'==$pdata['p-assessment-24'])
		$pdf->Image($checkMark,14.5, 225.5, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
		
if (array_key_exists('p-assessment-25',$pdata))
	if ('on'==$pdata['p-assessment-25'])
		$pdf->Image($checkMark,14.5, 229, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
		
if (array_key_exists('p-assessment-26',$pdata))
	if ('on'==$pdata['p-assessment-26'])
		$pdf->Image($checkMark,14.5, 233, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
$pdf->writeHTMLCell($w=10, $h=0, $x=90, $y=233, ((array_key_exists('p-reviewweek',$pdata))?$pdata['p-reviewweek']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 

if (array_key_exists('p-assessment-27',$pdata))
	if ('on'==$pdata['p-assessment-27'])
		$pdf->Image($checkMark,14.5, 236.5, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
		
if (array_key_exists('p-assessment-28',$pdata))
	if ('on'==$pdata['p-assessment-28'])
		$pdf->Image($checkMark,19, 240, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
$pdf->writeHTMLCell($w=40, $h=0, $x=103, $y=240, ((array_key_exists('p-refprovider',$pdata))?$pdata['p-refprovider']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 		
if (array_key_exists('p-assessment-29',$pdata))
	if ('on'==$pdata['p-assessment-29'])
		$pdf->Image($checkMark,19, 243.5, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
$pdf->writeHTMLCell($w=40, $h=0, $x=103, $y=243.5, ((array_key_exists('p-noprovider',$pdata))?$pdata['p-noprovider']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 		
if (array_key_exists('p-assessment-30',$pdata))
	if ('on'==$pdata['p-assessment-30'])
		$pdf->Image($checkMark,19, 251, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
		
if (array_key_exists('p-assessment-31',$pdata))
	if ('on'==$pdata['p-assessment-31'])
		$pdf->Image($checkMark,14.5, 254.5, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
$pdf->writeHTMLCell($w=40, $h=0, $x=90, $y=254.5, ((array_key_exists('p-withtxt',$pdata))?$pdata['p-withtxt']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 		 

if (''!=$data['data']['drsign']){
	//$imgdata = base64_decode(substr($data['data']['drsigntxt'],22));
	//$imgdata = str_replace(' ','+',$imgdata);
	
	$imgdata = $drsign;
	$imgdata = str_replace(' ','+',$imgdata);
	
	preg_match('#^data:[\w/]+(;[\w=]+)*,[\w+/=%]+$#', $imgdata);
	
	//echo $imgdata;
	copy("data:image/png;base64,".$imgdata,"output/temp.png");
	
	//file_put_contents("output/temp.png", $imgdata);
	//fclose($image);
	list($width, $height, $type, $attr)= getimagesize("output/temp.png"); 
	//echo substr($pdata['drsigntxt'],22);
	$pdf->Image("output/temp.png", 133, 274, 20, 20*$height/$width, '', '', '', false, 300, '', false, false, 0);
	//$pdf->Image("output/temp.png", 10, 10, 50, 20, '', '', '', false, 300, '', false, false, 0);
	//$pdf->Image('@'.$imgdata);
}

$pdf->writeHTMLCell($w=40, $h=0, $x=66, $y=56, ((array_key_exists('examdate',$pdata))?$pdata['examdate']:"").'  '.((array_key_exists('examtime',$pdata))?$pdata['examtime']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 

// redimed's detail
$pdf->writeHTMLCell($w=70, $h=0, $x=30, $y=269, ((array_key_exists('dname',$pdata))?$pdata['dname']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
$pdf->writeHTMLCell($w=70, $h=0, $x=143, $y=269, ((array_key_exists('dcode',$pdata))?$pdata['dcode']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
$pdf->writeHTMLCell($w=70, $h=0, $x=30, $y=273, ((array_key_exists('daddress',$pdata))?$pdata['daddress']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=70, $h=0, $x=30, $y=276.5, "(08) 9230 0900", $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
$pdf->writeHTMLCell($w=70, $h=0, $x=83, $y=276.5, "(08)9230 0999", $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);

?>