<?php
//print_r($pdata);
// get the current page break margin
$bMargin = $pdf->getBreakMargin();
// get current auto-page-break mode
$auto_page_break = $pdf->getAutoPageBreak();
// disable auto-page-break
$pdf->SetAutoPageBreak(false, 0);
// set bacground image
$img_file = "images/FirstMedicalCertRebrandedWord.png";
$checkMark = "images/CheckMark.jpg";
$pdf->Image($img_file, 0, 0, 210, 297, '', '', '', false, 250, '', false, false, 0);
// restore auto-page-break status
//$pdf->SetAutoPageBreak($auto_page_break, $bMargin);
// set the starting point for the page content
$pdf->setPageMark();
$pdf->setPage(1);

// start printing data
$pdf->writeHTMLCell($w=40, $h=0, $x=36, $y=41, $salutation[$data['data']['salut']-1].' '.$data['data']['gname'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); //first name
$pdf->writeHTMLCell($w=40, $h=0, $x=95, $y=41, $data['data']['fname'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // last name
$pdf->writeHTMLCell($w=140, $h=0, $x=31, $y=44.5, $data['data']['address'].(($data['data']['suburb']!='')?', ':'').$data['data']['suburb'].(($data['data']['postcode']!='')?', ':'').$data['data']['postcode'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // address
$pdf->writeHTMLCell($w=80, $h=0, $x=35, $y=48, $data['data']['wfone'].(($data['data']['hfone']!='')?'-':'').$data['data']['hfone'].(($data['data']['mfone']!='')?'-':'').$data['data']['mfone'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // fone
$pdf->writeHTMLCell($w=40, $h=0, $x=99, $y=48, $data['data']['dob'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // dob
$pdf->writeHTMLCell($w=40, $h=0, $x=149, $y=48, ((array_key_exists('occupation',$data['data']))?$data['data']['occupation']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // occupation
$pdf->Image($checkMark, 17, 52, 2.5, 2.5, '', '', '', false, 300, '', false, false, 0);
$pdf->writeHTMLCell($w=170, $h=8, $x=17, $y=64, $data['employer']['name'].' - '.$data['employer']['address'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // employer's detail
$pdf->writeHTMLCell($w=40, $h=0, $x=37, $y=104, $data['data']['adate'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // date
$pdf->writeHTMLCell($w=40, $h=0, $x=81, $y=108, $data['data']['alocation'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // location
$injDesc = ((array_key_exists('injdesc-1',$data['data']))?(('on'==$data['data']['injdesc-1'])?'Sprain/Strain':''):"").
		   ((array_key_exists('injdesc-2',$data['data']))?(('on'==$data['data']['injdesc-2'])?'Laceration, ':''):"").
		   ((array_key_exists('injdesc-3',$data['data']))?(('on'==$data['data']['injdesc-3'])?'Crush, ':''):"").
		   ((array_key_exists('injdesc-4',$data['data']))?(('on'==$data['data']['injdesc-4'])?'Fall. ':''):"").
		   ((array_key_exists('injdesctxt',$data['data']))?$data['data']['injdesctxt']:"");
// area of effect

$redLine = array('color' => array(255, 0, 0));
if (array_key_exists('bdypart-1',$data['data']))    // Left lower leg
	if ('on'==$data['data']['bdypart-1']){
		$pdf->Ellipse( 167.5, 130,2,4,0,0,360,'',$redLine,array(),2); 	
		$pdf->Ellipse( 185.5, 130,2,4,0,0,360,'',$redLine,array(),2); 	
	}
if (array_key_exists('bdypart-2',$data['data']))    // Right lower leg
	if ('on'==$data['data']['bdypart-2']){
		$pdf->Ellipse( 163.5, 130,2,4,0,0,360,'',$redLine,array(),2); 	
		$pdf->Ellipse( 188.5, 130,2,4,0,0,360,'',$redLine,array(),2); 	
	} 
if (array_key_exists('bdypart-3',$data['data']))    // Left upper leg
	if ('on'==$data['data']['bdypart-3']){
		$pdf->Ellipse( 168, 119,2,4,0,0,360,'',$redLine,array(),2); 	
		$pdf->Ellipse( 185, 119,2,4,0,0,360,'',$redLine,array(),2); 	
	}
if (array_key_exists('bdypart-4',$data['data']))    // Right upper leg
	if ('on'==$data['data']['bdypart-4']){
		$pdf->Ellipse( 164, 119,2,4,0,0,360,'',$redLine,array(),2); 	
		$pdf->Ellipse( 190, 119,2,4,0,0,360,'',$redLine,array(),2); 	
	}
if (array_key_exists('bdypart-5',$data['data']))    // Left lower arm
	if ('on'==$data['data']['bdypart-5']){
		$pdf->Ellipse( 172.5, 110,2,4,40,0,360,'',$redLine,array(),2); 	
		$pdf->Ellipse( 181, 110,2,4,-40,0,360,'',$redLine,array(),2)	;
	}
if (array_key_exists('bdypart-6',$data['data']))    // Right lower arm
	if ('on'==$data['data']['bdypart-6']){
		$pdf->Ellipse( 159.5, 110,2,4,-40,0,360,'',$redLine,array(),2); 	
		$pdf->Ellipse( 194, 110,2,4,40,0,360,'',$redLine,array(),2); 	
	}
if (array_key_exists('bdypart-7',$data['data']))    // Left upper arm
	if ('on'==$data['data']['bdypart-7']){
		$pdf->Ellipse( 171, 104,2,4,0,0,360,'',$redLine,array(),2); 	
		$pdf->Ellipse( 182.5, 104,2,4,0,0,360,'',$redLine,array(),2); 	
	} 
if (array_key_exists('bdypart-8',$data['data']))    // Right upper arm
	if ('on'==$data['data']['bdypart-8']){
		$pdf->Ellipse( 161, 104,2,4,0,0,360,'',$redLine,array(),2); 	
		$pdf->Ellipse( 192.5, 104,2,4,0,0,360,'',$redLine,array(),2); 	
	}
if (array_key_exists('bdypart-9',$data['data']))    // Left hand
	if ('on'==$data['data']['bdypart-9']){
		$pdf->Ellipse( 174, 117,3,3,0,0,360,'',$redLine,array(),2); 	
		$pdf->Ellipse( 179, 117,3,3,0,0,360,'',$redLine,array(),2); 	
	}
if (array_key_exists('bdypart-10',$data['data']))    // Right hand
	if ('on'==$data['data']['bdypart-10']){
		$pdf->Ellipse( 157, 117,3,3,0,0,360,'',$redLine,array(),2); 	
		$pdf->Ellipse( 196, 117,3,3,0,0,360,'',$redLine,array(),2); 	
	}
if (array_key_exists('bdypart-11',$data['data']))    // Left shoulder
	if ('on'==$data['data']['bdypart-11']){
		$pdf->Ellipse( 172, 99.5,3,3,0,0,360,'',$redLine,array(),2); 	
		$pdf->Ellipse( 183, 99.5,3,3,0,0,360,'',$redLine,array(),2); 	
	} 
if (array_key_exists('bdypart-12',$data['data']))    // Right shoulder
	if ('on'==$data['data']['bdypart-12']){
		$pdf->Ellipse( 161, 99.5,3,3,0,0,360,'',$redLine,array(),2); 	
		$pdf->Ellipse( 192, 99.5,3,3,0,0,360,'',$redLine,array(),2); 	
	} 
if (array_key_exists('bdypart-13',$data['data']))    // Abdomen
	if ('on'==$data['data']['bdypart-13']){
		$pdf->Ellipse( 166, 108,3,3,0,0,360,'',$redLine,array(),2); 	
	} 
if (array_key_exists('bdypart-14',$data['data']))    // Chest
	if ('on'==$data['data']['bdypart-14']){
		$pdf->Ellipse( 166, 102,5,3,0,0,360,'',$redLine,array(),2); 	
	} 
if (array_key_exists('bdypart-15',$data['data']))    // Lower back
	if ('on'==$data['data']['bdypart-15']){
		$pdf->Ellipse( 187, 105,3,3,0,0,360,'',$redLine,array(),2); 	
	}

$pdf->writeHTMLCell($w=80, $h=8, $x=63, $y=112, $injDesc, $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // desc
$pdf->writeHTMLCell($w=140, $h=8, $x=17, $y=122, $data['data']['reason'], $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // reason
$pdf->writeHTMLCell($w=140, $h=8, $x=17, $y=137, array_key_exists('massessment',$data['data'])?$data['data']['massessment']:"", $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); // assessment
if (array_key_exists('does',$data['data'])&&(1==$data['data']['does']))
	$pdf->Image($checkMark, 64.5, 147, 4, 4, '', '', '', false, 300, '', false, false, 0);
else
	$pdf->Image($checkMark, 92, 147, 4, 4, '', '', '', false, 300, '', false, false, 0);
//injury management
if (array_key_exists('assessment-1',$data['data'])) 
	if ('on'==$data['data']['assessment-1'])
		$pdf->Image($checkMark, 17, 169, 3, 3, '', '', '', false, 300, '', false, false, 0); //Fit to return to pre-injury duties
if (array_key_exists('assessment-2',$data['data']))
	if ('on'==$data['data']['assessment-2'])
		$pdf->Image($checkMark, 17, 172, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('assessment-3',$data['data']))
	if ('on'==$data['data']['assessment-3'])
		$pdf->Image($checkMark, 17, 175.5, 3, 3, '', '', '', false, 300, '', false, false, 0);
$pdf->writeHTMLCell($w=40, $h=0, $x=68, $y=175.5, ((array_key_exists('dateFrom',$data['data']))?$data['data']['dateFrom']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=40, $h=0, $x=87, $y=175.5, ((array_key_exists('dateTo',$data['data']))?$data['data']['dateTo']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
if (array_key_exists('assessment-4',$data['data']))
	if ('on'==$data['data']['assessment-4'])
		$pdf->Image($checkMark, 24, 179, 3, 3, '', '', '', false, 300, '', false, false, 0); //restricted hours
$pdf->writeHTMLCell($w=40, $h=0, $x=69, $y=179, ((array_key_exists('restrictedHours',$data['data']))?$data['data']['restrictedHours']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
if (array_key_exists('assessment-5',$data['data']))
	if ('on'==$data['data']['assessment-5'])
		$pdf->Image($checkMark, 24, 182.5, 3, 3, '', '', '', false, 300, '', false, false, 0);
$pdf->writeHTMLCell($w=40, $h=0, $x=69, $y=183, ((array_key_exists('restrictedDays',$data['data']))?$data['data']['restrictedDays']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
if (array_key_exists('assessment-6',$data['data']))
	if ('on'==$data['data']['assessment-6'])
		$pdf->Image($checkMark, 24, 186, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('assessment-7',$data['data']))
	if ('on'==$data['data']['assessment-7'])
		$pdf->Image($checkMark, 17, 189.5, 3, 3, '', '', '', false, 300, '', false, false, 0); //Work restrictions
if (array_key_exists('assessment-8',$data['data']))
	if ('on'==$data['data']['assessment-8'])
		$pdf->Image($checkMark, 24, 193, 3, 3, '', '', '', false, 300, '', false, false, 0); //
$pdf->writeHTMLCell($w=40, $h=0, $x=73, $y=192.5, ((array_key_exists('weight',$data['data']))?$data['data']['weight']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=60, $h=0, $x=117, $y=192.5, ((array_key_exists('otherRes',$data['data']))?$data['data']['otherRes']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
if (array_key_exists('assessment-9',$data['data']))
	if ('on'==$data['data']['assessment-9'])
		$pdf->Image($checkMark, 24, 196.5, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('assessment-10',$data['data']))
	if ('on'==$data['data']['assessment-10'])
		$pdf->Image($checkMark, 24, 200, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('assessment-11',$data['data']))
	if ('on'==$data['data']['assessment-11'])
		$pdf->Image($checkMark, 129, 196.5, 3, 3, '', '', '', false, 300, '', false, false, 0);// Avoid repetitive use
if (array_key_exists('assessment-12',$data['data']))
	if ('on'==$data['data']['assessment-12'])
		$pdf->Image($checkMark, 129, 200, 3, 3, '', '', '', false, 300, '', false, false, 0);  
if (array_key_exists('assessment-21',$data['data']))
	if ('on'==$data['data']['assessment-21'])
		$pdf->Image($checkMark, 146, 168, 3, 3, '', '', '', false, 300, '', false, false, 0);  // First and final certificate
if (array_key_exists('assessment-13',$data['data']))
	if ('on'==$data['data']['assessment-13'])
		$pdf->Image($checkMark, 17, 204.5, 3, 3, '', '', '', false, 300, '', false, false, 0); // unfit
$pdf->writeHTMLCell($w=15, $h=0, $x=59, $y=204, ((array_key_exists('unfitDays',$data['data']))?$data['data']['unfitDays']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=20, $h=0, $x=81, $y=204, ((array_key_exists('unfitFrom',$data['data']))?$data['data']['unfitFrom']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=20, $h=0, $x=99, $y=204, ((array_key_exists('unfitTo',$data['data']))?$data['data']['unfitTo']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
if (array_key_exists('assessment-14',$data['data']))
	if ('on'==$data['data']['assessment-14'])
		$pdf->Image($checkMark, 17, 213, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('assessment-15',$data['data']))
	if ('on'==$data['data']['assessment-15'])
		$pdf->Image($checkMark, 17, 216.5, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('assessment-17',$data['data']))
	if ('on'==$data['data']['assessment-17'])
		$pdf->Image($checkMark, 17, 220, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('assessment-16',$data['data']))
	if ('on'==$data['data']['assessment-16'])
		$pdf->Image($checkMark, 176, 217, 3, 3, '', '', '', false, 300, '', false, false, 0);
		
$pdf->setCellHeightRatio(0.8);
$pdf->SetFontSize(7, true);
$pdf->writeHTMLCell($w=160, $h=0, $x=37, $y=213, ((array_key_exists('medicationtxt',$data['data']))?$data['data']['medicationtxt']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
$pdf->writeHTMLCell($w=20, $h=0, $x=153, $y=216.5, ((array_key_exists('treatmenttxt',$data['data']))?$data['data']['treatmenttxt']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
$pdf->setCellHeightRatio(1.25);
$pdf->SetFontSize(8, true);
$pdf->writeHTMLCell($w=40, $h=0, $x=192, $y=216.5, ((array_key_exists('imagingtxt',$data['data']))?$data['data']['imagingtxt']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=100, $h=0, $x=73, $y=220, ((array_key_exists('refertxt',$data['data']))?$data['data']['refertxt']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=140, $h=0, $x=43, $y=224, ((array_key_exists('treatmentother',$data['data']))?$data['data']['treatmentother']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
$pdf->writeHTMLCell($w=40, $h=0, $x=89, $y=228, ((array_key_exists('datenext',$data['data']))?$data['data']['datenext']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=40, $h=0, $x=114, $y=228, ((array_key_exists('timenext',$data['data']))?$data['data']['timenext']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
if (array_key_exists('assessment-18',$data['data']))
	if ('on'==$data['data']['assessment-18'])
		$pdf->Image($checkMark, 17, 247.5, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('assessment-19',$data['data']))
	if ('on'==$data['data']['assessment-19'])
		$pdf->Image($checkMark, 17, 251, 3, 3, '', '', '', false, 300, '', false, false, 0);
if (array_key_exists('assessment-20',$data['data']))
	if ('on'==$data['data']['assessment-20'])
		$pdf->Image($checkMark, 17, 258, 3, 3, '', '', '', false, 300, '', false, false, 0);

if (''!=$data['data']['drsign']){
	//$imgdata = base64_decode(substr($data['data']['drsigntxt'],22));
	//$imgdata = str_replace(' ','+',$imgdata);
	
	$imgdata = $drsign;
	$imgdata = str_replace(' ','+',$imgdata);
	
	preg_match('#^data:[\w/]+(;[\w=]+)*,[\w+/=%]+$#', $imgdata);
	
	//echo $imgdata;
	copy("data:image/png;base64,".$imgdata,"output/temp.png");
	
	//file_put_contents("output/temp.png", $imgdata);
	//fclose($image);
	list($width, $height, $type, $attr)= getimagesize("output/temp.png"); 
	//echo substr($data['data']['drsigntxt'],22);
	$pdf->Image("output/temp.png", 136, 275, 20, 20*$height/$width, '', '', '', false, 300, '', false, false, 0);
	//$pdf->Image("output/temp.png", 10, 10, 50, 20, '', '', '', false, 300, '', false, false, 0);
	//$pdf->Image('@'.$imgdata);
}
if (array_key_exists('signtxt',$data['data'])&& (''!=$data['data']['signtxt'])){
	//$imgdata = base64_decode(substr($data['data']['drsigntxt'],22));
	//$imgdata = str_replace(' ','+',$imgdata);
	$imgdata = $data['data']['signtxt'];
	$imgdata = str_replace(' ','+',$imgdata);
	
	preg_match('#^data:[\w/]+(;[\w=]+)*,[\w+/=%]+$#', $imgdata);
	
	copy("data:image/png;base64,".$imgdata,"output/temp2.png");
	
	//file_put_contents("output/temp.png", $imgdata);
	//fclose($image);
	list($width, $height, $type, $attr)= getimagesize("output/temp2.png"); 
	//echo substr($data['data']['drsigntxt'],22);
	$pdf->Image("output/temp2.png", 45, 83, 8, 8*$height/$width, '', '', '', false, 300, '', false, false, 0);
	//$pdf->Image("output/temp.png", 10, 10, 50, 20, '', '', '', false, 300, '', false, false, 0);
	//$pdf->Image('@'.$imgdata);
}
$pdf->writeHTMLCell($w=40, $h=0, $x=126, $y=85, ((array_key_exists('createdTime',$data['entry']))? date("m/d/Y", strtotime($data['entry']['createdTime'])):""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 

//$pdf->writeHTMLCell($w=40, $h=0, $x=66, $y=56, ((array_key_exists('examdate',$data['data']))?$data['data']['examdate']:"").'  '.((array_key_exists('examtime',$data['data']))?$data['data']['examtime']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 

// redimed's detail
$pdf->writeHTMLCell($w=70, $h=0, $x=33, $y=267.5, ((array_key_exists('dname',$data['data']))?$data['data']['dname']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
$pdf->writeHTMLCell($w=70, $h=0, $x=143, $y=267.5, ((array_key_exists('dcode',$data['data']))?$data['data']['dcode']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
$pdf->writeHTMLCell($w=70, $h=0, $x=33, $y=270.7, ((array_key_exists('daddress',$data['data']))?$data['data']['daddress']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=70, $h=0, $x=33, $y=274.5, "(08) 9230 0900", $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
$pdf->writeHTMLCell($w=40, $h=0, $x=57, $y=278, ((array_key_exists('examdate',$data['data']))?$data['data']['examdate']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 
$pdf->writeHTMLCell($w=40, $h=0, $x=73, $y=278, ((array_key_exists('examtime',$data['data']))?$data['data']['examtime']:""), $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true); 

$pdf->writeHTMLCell($w=70, $h=0, $x=125, $y=274.5, "(08)9230 0999", $border=0, $ln=1, $fill=0, $reseth=true, $align='', $autopadding=true);
?>