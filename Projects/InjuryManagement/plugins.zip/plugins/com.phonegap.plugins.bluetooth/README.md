PhoneGap BluetoothPlugin
========================
Bluetooth plugin for PhoneGap (Android). Tested on versions 2.6.0 and 3.0.0.

**NOTE** The plugin requires Android API version 15 (Ice Cream Sandwich) to function properly.

This plugin was created as part of an EU funded (Rural Development Programme for
Mainland Finland 2007-2013) [project](http://blogit.jamk.fi/metsaapuilta/en/).

Read this first!
----------------
I'm currently in a situation where I do not have any equipment to test this plugin on, 
or develop reliably. Due to this situation, I am unable to maintain this plugin properly. 
I will still respond to pull requests and issues if I can help with them.

If you are interested in developing this plugin, fork it and make a pull request that 
will mention your fork here in this `README`. If you have your own Bluetooth plugin, 
that you would like to be mentioned here, make a pull request and add a link to it in 
this `README`. Pull requests to fix and add stuff will always be appreciated!

Installation
------------
Check out PhoneGap CLI [docs](http://docs.phonegap.com/en/3.0.0/guide_cli_index.md.html#The%20Command-line%20Interface)
before starting out.

To install this plugin on 3.0.0, use the phonegap CLI.

```
phonegap local plugin add https://github.com/tanelih/phonegap-bluetooth-plugin.git
```

Remember to build the project afterwards.

Installation below 3.0.0 version should be done manually. Copy the contents of
`manual/<platform>/src` and `manual/www` to their respective locations on your
project. Remember to add plugin specification to `config.xml` and permissions to
`AndroidManifest.xml`.

In `config.xml`...
```
<plugin name="Bluetooth" value="org.apache.cordova.bluetooth.BluetoothPlugin" />
```

In `AndroidManifest.xml`...
```
<uses-permission android:name="android.permission.BLUETOOTH" />
<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" />
```

Usage
-----

If you installed the plugin with plugman in 3.0.0 environment, the plugin is
accessible from `window.bluetooth`.

If you installed the plugin manually, you need to add the `bluetooth.js` script
to your app. Then require the plugin after the `deviceready` event.

```
window.bluetooth = cordova.require("cordova/plugin/bluetooth");
```

License
-------
This plugin is available under MIT. See LICENSE for details.



 === Received Data:
 D0
 00  00
 41  0A  51  2A  00  00  00
 40  7B
 40  66
 40  29
 3F  6C
 3F  71
 3F  0A  3E  38  3E  0F  3E  4D  3F  33  3F  43  40  3D  40  24  40  4D  40  61  40  38  40  0F  40  66  40  3D  40  29  40  29  40  29  40  29  40  29  40  29  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00  00
 === Received Data: 11010000  00000000  00000000  01000001  00001010  01010001  00101010  00000000  00000000  00000000  01000000  01111011  01000000  01100110  01000000  00101001  00111111  01101100  00111111  01110001  00111111  00001010  00111110  00111000  00111110  00001111  00111110  01001101  00111111  00110011  00111111  01000011  01000000  00111101  01000000  00100100  01000000  01001101  01000000  01100001  01000000  00111000  01000000  00001111  01000000  01100110  01000000  00111101  01000000  00101001  01000000  00101001  01000000  00101001  01000000  00101001  01000000  00101001  01000000  00101001  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000  00000000